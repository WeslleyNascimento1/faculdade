package com.projeto.projetoW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoWApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoWApplication.class, args);
	}

}
