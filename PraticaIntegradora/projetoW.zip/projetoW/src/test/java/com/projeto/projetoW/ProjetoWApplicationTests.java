package com.projeto.projetoW;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoWApplicationTests {

	@Test
	void contextLoads() {
	}

}
